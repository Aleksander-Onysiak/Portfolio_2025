<?php /*Template Name: Template "Mes projets"*/ ?>

<?= get_header() ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div><?php the_content() ?></div>
<?php endwhile; else : ?>

    <p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>
<div>
    <p role="heading" aria-level="2" class="projects__main">Mes projets</p>
    <p role="heading" aria-level="2" class="projects__second">les plus récents</p>
</div>
<?php
$projets = new WP_Query([
    'post_type' => 'project',
    'posts_per_page' => 4,
    'post_status' => 'publish',
    'lang' => '',
]);
?>
<section class="template_projects">
    <?php if ($projets->have_posts()) :
        while ($projets->have_posts()) : $projets->the_post(); ?>
            <div tabindex="0" class="template_project__card">
                <a class="template_project__card-link" href="<?= get_the_permalink(); ?>"
                   title="Ce lien vous amènera vers la page du projet">
                    <div class="template_project__card-text-container">
                        <img class="template_project__card-image" src="<?= get_the_post_thumbnail_url() ?>" alt=""
                             width="300" height="300">
                        <h3 role="heading" aria-level="3"
                            class="template_project__card-title"><?= get_the_title(); ?></h3>
                        <p class="template_project__card-link">Voir le projet</p>
                    </div>
                </a>
            </div>
        <?php endwhile;
        wp_reset_postdata(); endif; ?>
</section>
<?= get_footer() ?>
