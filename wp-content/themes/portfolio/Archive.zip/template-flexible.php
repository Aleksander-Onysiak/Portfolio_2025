<?php /* Template Name: Template Flexible */ ?>

<?php get_header() ?>

<?php include ('templates/partials/stage.php'); ?>
<?php include ('templates/flexible.php'); ?>

<?php get_footer() ?>