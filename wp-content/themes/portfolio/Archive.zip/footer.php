</main>
<!--création d'une boucle de contenu propre à wordpress-->
<footer class="footer">
    <section class="footer__section">
        <h2 class="sr-only">Footer</h2>
        <div class="footer__div">
            <h3 class="footer__div__title"><a href="#">Aleksander Onysiak</a></h3>
            <p class="footer__div__p">Vous êtes descendu jusqu'à mon footer!</p>
            <p class="footer__div__p"> N'hesitez pas à me suivre sur mes réseaux et me contacter via ceux-ci !</p>
        </div>
        <div class="footer__menu" itemtype="https://schema.org/PostalAddress">
            <h3 class="footer-menu__sublist__title">Mes coordonnées</h3>
            <ul itemprop="address" itemscope="" class="footer-menu__sublist">
                <li class="footer-menu__sublist-item">
                    Aleksander Onysiak
                </li>
                <li class="footer-menu__sublist-item">
                    <span itemprop="telephone">+32 (0)471 21 32 47</span>
                </li>
                <li class="footer-menu__sublist-item">
                    <a href="" itemprop="email"
                       class="footer-menu__sublist-item__content">contact@aleksanderonysiak.com</a>
                </li>
                <li class="footer-menu__sublist-item">
                    <span data-adress="pays">Belgique</span>
                </li>
            </ul>
        </div>
        <div class="footer__menu" itemtype="https://schema.org/PostalAddress">
            <h3 class="footer-menu__sublist__title proj">Mes projets</h3>
            <ul itemscope itemtype="https://schema.org/" class="footer-menu__sublist">
                <li class="footer-menu__sublist-item" itemprop="">
                    <a href="#" class="footer-menu__sublist-item__content">Toy Photography</a>
                </li>
                <li class="footer-menu__sublist-item" itemprop="">
                    <a href="#" class="footer-menu__sublist-item__content">Site Client</a>
                </li>
                <li class="footer-menu__sublist-item" itemprop="">
                    <a href="#" class="footer-menu__sublist-item__content">PFE</a>
                </li>
            </ul>
        </div>
        <div class="footer__menu" itemtype="https://schema.org/PostalAddress">
            <h3 class="footer-menu__sublist__title soc">Mes réseaux sociaux</h3>
            <ul itemscope itemtype="https://schema.org/" class="footer-menu__sublist">
                <li class="footer-menu__sublist-item" itemprop="">
                    <a href="https://github.com/Aleksander-Onysiak" class="footer-menu__sublist-item__content">GitHub</a>
                </li>
                <li class="footer-menu__sublist-item" itemprop="">
                    <a href="https://www.linkedin.com/in/aleksander-onysiak-936032236/" class="footer-menu__sublist-item__content">Linkedin</a>
                </li>
                <li class="footer-menu__sublist-item" itemprop="">
                    <a href="" class="footer-menu__sublist-item__content">Telegram</a>
                </li>
            </ul>
        </div>
    </section>
    <div class="footer-bottom__reserved">
        <div class="footer-bottom__reserved">&copy; 2025 Aleksander Onysiak. Tous droits réservés.</div>
    </div>
</footer>
</body>

</html>