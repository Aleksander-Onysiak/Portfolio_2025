<?= get_header('custom') ?>

<h2 class="sr-only">Header du Portfolio</h2>

<section class="front-container">
    <div>
        <h2 class="title"><a href="#">Aleksander Onysiak</a></h2>
        <h3 class="subtitle"><?= __('DEVELOPPEUR WEB', 'textdomain') ?></h3>
        <!--<img class="profile__image" src="<?= esc_url($image); ?>" alt="ma photo personnelle">-->

        <!--<div class="svg_planets">
            <svg  class="planet_svg-1" width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="26" fill="#d9d9d9" stroke="#ffffff" stroke-width="2"/>
                <circle cx="42" cy="42" r="4" fill="#c2c2c2" />
                <circle cx="56" cy="60" r="3" fill="#c2c2c2" />
                <circle cx="60" cy="38" r="2.5" fill="#c2c2c2" />
            </svg>
            <svg class="planet_svg-2" width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="24" fill="#ffb347" stroke="#ffffff" stroke-width="2"/>
                <ellipse cx="50" cy="50" rx="36" ry="8" fill="none" stroke="#ffffff" stroke-width="2" transform="rotate(-15 50 50)" />
            </svg>
            <svg class="planet_svg-3" width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="28" fill="#8ab6d6" stroke="#ffffff" stroke-width="3"/>
                <ellipse cx="50" cy="50" rx="40" ry="10" fill="none" stroke="#ffffff" stroke-width="2" transform="rotate(25 50 50)" />
            </svg>
        </div>-->

        <div>
            <button class="btn-contact" type="submit">
                <?= __('Me contacter', 'hdc-trad') ?>
            </button>
        </div>

    </div>
</section>

<div class="front-project__container">
    <div role="heading" aria-level="2" class="front-project__quote">
        Passionné par le développement, voici quelques unes de mes réalisations récentes
    </div>
    <button class="front-project__btn" type="button">
        <a class="front-project__btn-a"
           href="http://portfolio-2025.test/contact/"> <?= __('Me contacter pour plus d\'infos', 'hdc-trad') ?></a>
    </button>
</div>

<?php
$projets = new WP_Query([
    'post_type' => 'project',
    'posts_per_page' => 4,
    'post_status' => 'publish',
    'lang' => '',
]);
?>
<section class="template_projects">
    <?php if ($projets->have_posts()) :
        while ($projets->have_posts()) : $projets->the_post(); ?>
            <div tabindex="0" class="template_project__card">
                <a class="template_project__card-link" href="<?= get_the_permalink(); ?>"
                   title="Ce lien vous amènera vers la page du projet">
                    <div class="template_project__card-text-container">
                        <img class="template_project__card-image" src="<?= get_the_post_thumbnail_url() ?>" alt=""
                             width="300" height="300">
                        <h3 role="heading" aria-level="3"
                            class="template_project__card-title"><?= get_the_title(); ?></h3>
                        <p class="template_project__card-link">Voir le projet</p>
                    </div>
                </a>
            </div>
        <?php endwhile;
        wp_reset_postdata(); endif; ?>
</section>
<?php include('templates/flexible.php'); ?>

<section class="end-quote">
    <div>
        <h2 class="end_contact__title"><?= __('Un Projet, une Idée ?', 'textdomain') ?></h2>
        <h3 class="end_contact__subtitle"><?= __('Contactez-moi pour un stage', 'textdomain') ?></h3>
    </div>
    <button class="btn-contact" type="submit"><?= __('Me contacter', 'textdomain') ?></button>
</section>

<?= get_footer('custom') ?>

