<?= get_header() ?>
    <h1 class="page-project_title"><?= get_the_title(); ?></h1>
    <div class="thumbnail"><?php the_post_thumbnail('single-post-thumbnail'); ?></div>
    <section class="project_section">
        <?php if (have_rows('projects')): ?>
            <?php while (have_rows('projects')): the_row();
                $title = get_sub_field('title');
                $project_title = get_sub_field('project_title');
                $description = get_sub_field('description', false, false);
                $image = get_sub_field('image');
                $image_2 = get_sub_field('image_2');
                ?>
                <div class="project_section_heading">
                    <h3 class="project_section_title"><?= esc_html($title); ?></h3>
                    <p class="project_section_description"><?= esc_html($description); ?></p>
                </div>
                <div class="project_image_container">
                    <?php if (!empty($image)) : ?>
                        <img src="<?= esc_url(get_the_post_thumbnail_url()); ?>"
                             alt="<?= esc_attr(get_the_title()); ?>" class="project_section_img">
                    <?php endif; ?>

                    <?php if (!empty($image_2)) : ?>
                        <img src="<?= esc_url(get_the_post_thumbnail_url()); ?>"
                             alt="<?= esc_attr(get_the_title()); ?>" class="project_section_img">
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php else : ?>
            <p>Sorry, no projects found.</p>
        <?php endif; ?>
    </section>
    <section class="other-project__section">
        <?php
        $projets = new WP_Query([
            'post_type' => 'project',
            'post_per_page' => 3,
            'post_status' => 'publish',
        ]);

        if ($projets->have_posts()) :
            ?>
            <div class="other-project__container">
                <h2 role="heading" aria-level="2" class="other-project__quote-header">
                    D’autres projets
                </h2>
                <h3 class="other-project__quote-subheader">
                    tout aussi intéressants
                </h3>
            </div>
            <div id="cards" class="other-projects">
                <?php while ($projets->have_posts()) : $projets->the_post(); ?>
                    <article tabindex="0" class="other-project__card">
                        <div class="opacity">
                            <a class="project__card-link-sro" href="<?= get_the_permalink(); ?>"
                               title="Ce lien vous amènera vers la page du projet">
                                <div class="other-project__card-container">
                                    <img class="other-project__card-image"
                                         src="<?= esc_url(get_the_post_thumbnail_url()); ?>"
                                         alt="<?= esc_attr(get_the_title()); ?>" width="300" height="300">
                                    <div class="other-project-link">
                                        <h2 role="heading" aria-level="3"
                                            class="other-project__card-title"><?= get_the_title(); ?></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
            <?php
            wp_reset_postdata();
        endif;
        ?>
    </section>
<?= get_footer() ?>